<?php
/**
 * Plugin Name: Redis Hawk Monitoring
 * Plugin URI:  https://aubin.dev
 * Description: Redis Hawk Monitoring supervise Redis, optimise le cache, offre alertes, et améliore la performance WordPress.
 * Version: 2.2
 * Author: Aubin MIENANZAMBI
 * Author URI: https://aubin.dev
 * Text Domain: redis-hawk-monitoring
 * Domain Path: /languages
 * License: GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Empêche un accès direct
}

/**
 * Chargement du textdomain pour la traduction.
 */
add_action( 'plugins_loaded', function() {
    load_plugin_textdomain(
        'redis-hawk-monitoring',
        false,
        dirname( plugin_basename( __FILE__ ) ) . '/languages/'
    );
});

/**
 * Inclusion des fichiers du plugin.
 * À adapter selon votre arborescence.
 */
require_once plugin_dir_path( __FILE__ ) . 'inc/enqueue-scripts.php';
require_once plugin_dir_path( __FILE__ ) . 'inc/flush-redis.php';
require_once plugin_dir_path( __FILE__ ) . 'inc/admin-menus.php';
require_once plugin_dir_path( __FILE__ ) . 'inc/monitoring-dashboard.php';
