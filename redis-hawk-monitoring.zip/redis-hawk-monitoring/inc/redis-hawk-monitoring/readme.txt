=== Redis Hawk Monitoring ===
Contributors: aubinmienanzambi
Donate link: https://aubin.dev/donate
Tags: redis, cache, performance, monitoring
Requires at least: 4.9
Tested up to: 6.3
Requires PHP: 7.2
Stable tag: 2.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Redis Hawk Monitoring is a comprehensive dashboard to monitor Redis usage and server resources from your WordPress admin.

== Description ==

Redis Hawk Monitoring provides a quick view on how your Redis cache is performing, as well as some server metrics like CPU usage, PHP version, and memory usage. You can also manually flush your Redis cache directly from the WordPress admin.

Features:
* Check Redis connection status, version, and memory usage.
* View CPU load average (for multi-core systems).
* See Redis fragmentation ratio, connected clients, and other stats.
* Flush Redis cache with a single click.
* Instructions to configure Redis in WordPress.

== Installation ==

1. Install the plugin via the WordPress plugins screen directly, or upload the plugin folder to `/wp-content/plugins/`.
2. Activate the plugin through the ‘Plugins’ screen in WordPress.
3. Make sure you have Redis installed and running on your server.
4. Optionally, add the following constants in your `wp-config.php`:

    ```php
    define('REDIS_HOST', '127.0.0.1');
    define('REDIS_PORT', 6379);
    define('REDIS_PREFIX', 'my_unique_prefix_');
    define('WP_CACHE', true); // Enable WP Cache
    ```

5. Ensure `object-cache.php` is present in your `wp-content` directory if required by your Redis solution.

== Frequently Asked Questions ==

= Do I need to install Redis on my server? =
Yes. This plugin requires an operational Redis service to connect to.

= My Redis is running on a different host / port, how do I configure it? =
Define the constants `REDIS_HOST` and `REDIS_PORT` in your `wp-config.php`. For example:
```php
define('REDIS_HOST', 'my-redis-host.com');
define('REDIS_PORT', 6380);
