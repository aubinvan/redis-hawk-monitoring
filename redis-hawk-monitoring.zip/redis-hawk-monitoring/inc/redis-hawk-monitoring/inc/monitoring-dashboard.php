<?php
// Empêcher un accès direct.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ---------------------------------------------------------
 * 1) Enregistrer l'action AJAX pour forcer le téléchargement
 * ---------------------------------------------------------
 */
add_action( 'wp_ajax_forced_download_objectcache', 'rdshkm_forced_download_objectcache' );
function rdshkm_forced_download_objectcache() {
    // Vérifier la capacité (ex: être administrateur)
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( 'Accès refusé.', 'Erreur', 403 );
    }

    // Chemin local vers le fichier object-cache.php dans votre plugin
    // Suppose : /wp-content/plugins/redis-hawk-monitoring/assets/object-cache.php
    $file_path = WP_PLUGIN_DIR . '/redis-hawk-monitoring/assets/object-cache.php';

    // Vérifier l'existence du fichier
    if ( ! file_exists( $file_path ) ) {
        wp_die( 'Fichier introuvable sur le serveur.' );
    }

    // Définir les en-têtes pour forcer le téléchargement
    header( 'Content-Description: File Transfer' );
    header( 'Content-Type: application/octet-stream' );
    header( 'Content-Disposition: attachment; filename="object-cache.php"' );
    header( 'Content-Transfer-Encoding: binary' );
    header( 'Expires: 0' );
    header( 'Cache-Control: must-revalidate' );
    header( 'Pragma: public' );
    header( 'Content-Length: ' . filesize( $file_path ) );

    // Envoyer le contenu du fichier
    readfile( $file_path );
    exit; // Terminer proprement
}

/**
 * ---------------------------------------------------------
 * 2) Fonction principale : "monitoring_dashboard_page()"
 *    - Affiche le tableau de bord
 *    - Gère le flush Redis
 *    - Montre le bouton de téléchargement local object-cache.php (si absent)
 * ---------------------------------------------------------
 */
function monitoring_dashboard_page() {

    /**
     * A) Si l'utilisateur a cliqué sur "Vider le cache Redis",
     *    on exécute le flushAll() via Redis.
     */
    if ( isset( $_POST['flush_redis'] ) ) {
        try {
            $redis = new Redis();
            // On se connecte en dur ici pour vider Redis ;
            // ajustez si vous souhaitez WP_REDIS_HOST / WP_REDIS_PORT pour être cohérent.
            $redis->connect( '127.0.0.1', 6379 );
            $redis->flushAll();

            add_action( 'admin_notices', function() {
                echo '<div class="notice notice-success is-dismissible">
                        <p>Le cache Redis a été vidé avec succès.</p>
                      </div>';
            } );
        } catch ( Exception $e ) {
            add_action( 'admin_notices', function() use ( $e ) {
                echo '<div class="notice notice-error is-dismissible">
                        <p>Erreur lors du vidage du cache Redis : ' . esc_html( $e->getMessage() ) . '</p>
                      </div>';
            } );
        }
    }

    // --- Variables par défaut pour Redis / WP ---
    $redis_status         = 'Non connecté';
    $redis_version        = 'Inconnue';
    $redis_memory         = 'Inconnue';
    $redis_memory_max     = 'Inconnue';
    $redis_fragmentation  = 'Inconnue';
    $redis_clients        = 'Inconnu';
    $redis_evicted_keys   = 'Inconnu';
    // On utilise WP_REDIS_PREFIX si défini, sinon 'Non défini'
    $redis_prefix         = defined('WP_REDIS_PREFIX') ? WP_REDIS_PREFIX : 'Non défini';
    $redis_test_result    = 'Non testé';
    $redis_input_kbps     = 'Inconnu';
    $redis_output_kbps    = 'Inconnu';
    $redis_errors         = [];

    // Vérifier si object-cache.php existe dans wp-content/
    $object_cache_path   = WP_CONTENT_DIR . '/object-cache.php';
    $object_cache_exists = file_exists( $object_cache_path );

    // WP_CACHE activé ?
    $wp_cache_status     = ( defined('WP_CACHE') && WP_CACHE ) ? 'Actif' : 'Inactif';

    // Tentative de connexion Redis + récupération d'infos
    // ICI on vérifie WP_REDIS_HOST / WP_REDIS_PORT pour être en phase avec votre wp-config.
    if ( $object_cache_exists && defined('WP_REDIS_HOST') && defined('WP_REDIS_PORT') ) {
        try {
            $redis = new Redis();
            // Connect avec WP_REDIS_HOST et WP_REDIS_PORT
            $redis->connect( WP_REDIS_HOST, WP_REDIS_PORT );
            $redis_info            = $redis->info();
            $redis_status          = 'Connecté';
            $redis_version         = $redis_info['redis_version'] ?? 'Inconnue';
            $redis_memory          = isset( $redis_info['used_memory'] ) ? size_format( $redis_info['used_memory'] ) : 'Inconnue';
            $redis_memory_max      = ( isset( $redis_info['maxmemory']) && $redis_info['maxmemory'] > 0 )
                                        ? size_format( $redis_info['maxmemory'] )
                                        : 'Illimitée';
            $redis_fragmentation   = $redis_info['mem_fragmentation_ratio'] ?? 'Inconnue';
            $redis_clients         = $redis_info['connected_clients'] ?? 'Inconnu';
            $redis_evicted_keys    = $redis_info['evicted_keys'] ?? 'Inconnu';
            $redis_input_kbps      = $redis_info['instantaneous_input_kbps'] ?? 'Inconnu';
            $redis_output_kbps     = $redis_info['instantaneous_output_kbps'] ?? 'Inconnu';

            // Test de clé Redis
            $test_key = 'hawk_monitoring_test';
            $redis->set( $test_key, 'Redis fonctionne correctement' );
            $test_value = $redis->get( $test_key );
            $redis_test_result = ( $test_value === 'Redis fonctionne correctement' )
                ? 'Redis est fonctionnel'
                : 'Redis a échoué';

        } catch ( Exception $e ) {
            $redis_status = 'Erreur';
            $redis_errors[] = $e->getMessage();
        }
    } else {
        // Si WP_REDIS_HOST/PORT ne sont pas définies => msg d’erreur
        $redis_status = 'wp-config.php mal configuré ou object-cache.php absent';
        if ( ! $object_cache_exists ) {
            $redis_errors[] = 'Le fichier object-cache.php est absent dans wp-content.';
        }
        if ( ! defined('WP_REDIS_HOST') || ! defined('WP_REDIS_PORT') ) {
            $redis_errors[] = 'Les constantes WP_REDIS_HOST et WP_REDIS_PORT ne sont pas définies.';
        }
    }

    // --- Infos système ---
    $memory_usage     = size_format( memory_get_usage( true ) );
    $cpu_load         = sys_getloadavg();
    // Hypothèse : machine 4 coeurs => calcul approximatif
    $cpu_load_percent = isset( $cpu_load[0] ) ? round( $cpu_load[0] * 100 / 4, 2 ) . '%' : 'Inconnu';
    $php_version      = phpversion();

    // --- Alertes ---
    $alerts = [];
    if (
        isset( $redis_info['used_memory'], $redis_info['maxmemory'] ) &&
        ( $redis_memory_max !== 'Illimitée' ) &&
        ( $redis_info['maxmemory'] > 0 ) &&
        ( $redis_info['used_memory'] / $redis_info['maxmemory'] ) > 0.8
    ) {
        $alerts[] = 'La mémoire Redis utilisée dépasse 80 % de la limite maximale.';
    }
    if ( isset( $redis_info['connected_clients'] ) && $redis_info['connected_clients'] > 50 ) {
        $alerts[] = 'Le nombre de clients connectés dépasse 50.';
    }

    // URL de l'action AJAX pour forcer le téléchargement
    $download_url = admin_url( 'admin-ajax.php?action=forced_download_objectcache' );
    ?>

    <!-- HTML du Dashboard -->
    <div class="wrap monitoring-dashboard">
        <h1>Hawk Monitoring</h1>

        <table>
            <thead>
                <tr>
                    <th>Catégorie</th>
                    <th>Information</th>
                    <th>Valeur</th>
                </tr>
            </thead>
            <tbody>
                <!-- Serveur -->
                <tr>
                    <td>Serveur</td>
                    <td>Charge CPU</td>
                    <td><?php echo esc_html( $cpu_load_percent ); ?></td>
                </tr>
                <tr>
                    <td>Serveur</td>
                    <td>Version PHP</td>
                    <td><?php echo esc_html( $php_version ); ?></td>
                </tr>

                <!-- WordPress -->
                <tr>
                    <td>WordPress</td>
                    <td>WP_CACHE</td>
                    <td class="<?php echo ( $wp_cache_status === 'Actif' ) ? 'status-ok' : 'status-error'; ?>">
                        <?php echo esc_html( $wp_cache_status ); ?>
                    </td>
                </tr>

                <!-- Redis -->
                <tr>
                    <td>Redis</td>
                    <td>Statut</td>
                    <td class="<?php echo ( $redis_status === 'Connecté' ) ? 'status-ok' : 'status-error'; ?>">
                        <?php echo esc_html( $redis_status ); ?>
                    </td>
                </tr>
                <tr>
                    <td>Redis</td>
                    <td>Fichier object-cache.php</td>
                    <td><?php echo ( $object_cache_exists ) ? 'Présent' : 'Absent'; ?></td>
                </tr>
                <tr>
                    <td>Redis</td>
                    <td>Version</td>
                    <td><?php echo esc_html( $redis_version ); ?></td>
                </tr>
                <tr>
                    <td>Redis</td>
                    <td>Test de connexion</td>
                    <td><?php echo esc_html( $redis_test_result ); ?></td>
                </tr>
                <tr>
                    <td>Redis</td>
                    <td>Mémoire utilisée</td>
                    <td><?php echo esc_html( $redis_memory ); ?></td>
                </tr>
                <tr>
                    <td>Redis</td>
                    <td>Mémoire maximale</td>
                    <td><?php echo esc_html( $redis_memory_max ); ?></td>
                </tr>
                <tr>
                    <td>Redis</td>
                    <td>Fragmentation</td>
                    <td><?php echo esc_html( $redis_fragmentation ); ?></td>
                </tr>
                <tr>
                    <td>Redis</td>
                    <td>Clients connectés</td>
                    <td><?php echo esc_html( $redis_clients ); ?></td>
                </tr>
                <tr>
                    <td>Redis</td>
                    <td>Clés expulsées</td>
                    <td><?php echo esc_html( $redis_evicted_keys ); ?></td>
                </tr>
                <tr>
                    <td>Redis</td>
                    <td>Préfixe</td>
                    <td><?php echo esc_html( $redis_prefix ); ?></td>
                </tr>
                <tr>
                    <td>Redis</td>
                    <td>Débit entrant</td>
                    <td><?php echo esc_html( $redis_input_kbps ) . ' kbps'; ?></td>
                </tr>
                <tr>
                    <td>Redis</td>
                    <td>Débit sortant</td>
                    <td><?php echo esc_html( $redis_output_kbps ) . ' kbps'; ?></td>
                </tr>
            </tbody>
        </table>

        <!-- Bouton pour vider le cache Redis -->
        <form method="post" style="margin-bottom: 20px;">
            <button type="submit" name="flush_redis" class="flush-button">
                Vider le cache Redis
            </button>
        </form>

        <!-- Affichage des alertes éventuelles -->
        <?php if ( ! empty( $alerts ) ) : ?>
            <div class="alert">
                <h3>Alertes :</h3>
                <ul>
                    <?php foreach ( $alerts as $alert ) : ?>
                        <li><?php echo esc_html( $alert ); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Affichage des erreurs Redis -->
        <?php if ( ! empty( $redis_errors ) ) : ?>
            <div class="errors">
                <h3>Erreurs Redis :</h3>
                <ul>
                    <?php foreach ( $redis_errors as $error ) : ?>
                        <li><?php echo esc_html( $error ); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

<!-- Configuration Redis -->
<div class="configuration">
    <h3>Instructions pour configurer Redis sur WordPress :</h3>
    <p>Ajoutez les lignes suivantes à votre fichier <code>wp-config.php</code> :</p>
    <pre><code>// Active la mise en cache WordPress
define('WP_CACHE', true);

// Configuration Redis
define('WP_REDIS_HOST', '127.0.0.1');
define('WP_REDIS_PORT', 6379);
define('WP_REDIS_PREFIX', 'namesite_'); // Remplacez 'namesite_' par un préfixe unique pour chaque site
define('WP_REDIS_DATABASE', 0); 
</code></pre>
    <p>Assurez-vous que <code>object-cache.php</code> est bien présent dans le répertoire <code>wp-content</code>.</p>
    
    <!-- Note informative pour l'administrateur -->
    <div class="note">
        <p>Avant d'activer cette configuration, assurez-vous que Redis est installé et fonctionnel sur votre serveur. Pour éviter toute confusion entre plusieurs sites, remplacez <code>'namesite_'</code> par un préfixe unique correspondant au nom de votre site par exemple.</p>
        <p>Si vous rencontrez des problèmes avec votre site, vous pouvez facilement revenir au système de cache par défaut en <strong>supprimant</strong> le fichier <code>object-cache.php</code> du répertoire <code>wp-content</code>.</p>
    </div>
</div>

<hr/>


        <!-- Bouton de téléchargement object-cache.php SI absent -->
        <div class="download-object-cache">
            <h3>Télécharger object-cache.php (localement)</h3>
            <p>
                <?php if ( $object_cache_exists ) : ?>
                    <button class="button" disabled>
                        object-cache.php déjà présent
                    </button>
                    <small style="color:#777;">
                        (Le fichier <code>object-cache.php</code> est déjà dans <code>wp-content</code>.)
                    </small>
                <?php else : ?>
                    <a class="button button-primary"
                       href="<?php echo esc_url( $download_url ); ?>">
                        Télécharger object-cache.php
                    </a>
                    <small>
                        (Actuellement absent de <code>wp-content</code>.)
                    </small>
                <?php endif; ?>
            </p>
        </div>

        <div class="credits" style="margin-top:20px;">
            <p>Développé par <a href="https://aubin.dev" target="_blank">Aubin MIENANZAMBI</a>. 
               Plugin sous licence <strong>GNU</strong>.</p>
        </div>
    </div>
    <?php
}
