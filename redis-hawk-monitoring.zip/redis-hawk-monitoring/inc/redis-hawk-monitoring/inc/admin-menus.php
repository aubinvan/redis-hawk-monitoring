<?php
// Empêcher l'accès direct.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Ajoute un item de menu "Redis Hawk" dans l'admin WordPress.
 */
function rdshkm_add_admin_menu() {
    add_menu_page(
        'Hawk Monitoring',           // Titre de la page
        'Redis Hawk',               // Texte du menu
        'manage_options',           // Capacité requise
        'monitoring-dashboard',     // Slug unique
        'monitoring_dashboard_page',// Fonction de rappel (affichage du contenu)
        '',                         // Icône (ici, vide car on utilise Font Awesome en CSS)
        90                          // Position dans le menu
    );
}
add_action( 'admin_menu', 'rdshkm_add_admin_menu' );
