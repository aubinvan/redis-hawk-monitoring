<?php
// Empêcher l'accès direct.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Vérifie si le formulaire de vidage Redis a été soumis
 * et effectue l'opération si besoin.
 */
function rdshkm_check_and_flush_redis() {
    if ( isset( $_POST['flush_redis'] ) ) {
        try {
            $redis = new Redis();
            $redis->connect( '127.0.0.1', 6379 );
            $redis->flushAll();

            // Affiche un message de succès dans l'admin.
            add_action( 'admin_notices', function() {
                echo '<div class="notice notice-success is-dismissible">
                    <p>Le cache Redis a été vidé avec succès.</p>
                </div>';
            } );

        } catch ( Exception $e ) {
            // Affiche un message d'erreur si la connexion ou le flush échoue.
            add_action( 'admin_notices', function() use ( $e ) {
                echo '<div class="notice notice-error is-dismissible">
                    <p>Erreur lors du vidage du cache Redis : ' . esc_html( $e->getMessage() ) . '</p>
                </div>';
            } );
        }
    }
}
add_action( 'admin_init', 'rdshkm_check_and_flush_redis' );
