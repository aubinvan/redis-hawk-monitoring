<?php
// Empêcher l'accès direct.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Enfile les styles et scripts nécessaires dans l'admin.
 */
function rdshkm_enqueue_admin_assets() {
    // Charger la dernière version de Font Awesome.
    wp_enqueue_style(
        'font-awesome',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css',
        array(),
        '6.0.0-beta3'
    );

    // Charger le style personnalisé du plugin.
    wp_enqueue_style(
        'redis-hawk-styles',
        plugin_dir_url( __FILE__ ) . '../assets/styles.css',
        array(),
        '1.0'
    );
}
add_action( 'admin_enqueue_scripts', 'rdshkm_enqueue_admin_assets' );
